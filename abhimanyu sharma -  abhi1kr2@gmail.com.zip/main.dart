import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Welcome to Flutter',
      home: Scaffold(
        appBar: AppBar(
          title: Text('INSTAGRAM',style: TextStyle(color: Colors.black),),
          leading: Icon(Icons.camera_alt,color: Colors.black,),
          backgroundColor: Colors.white,

          actions: <Widget>[
            Icon(Icons.tv,color: Colors.black,),
            Icon(Icons.send,color: Colors.black,),
          ],

        ),
      ),
    );
  }
}

 Widget buildInstagramTile(){
  return Column(
    children: <Widget>[
      ListTile(
        leading: Image.network(
          'https://www.google.com/url?sa=i&source=imgres&cd=&cad=rja&uact=8&ved=2ahUKEwjOlc6Hhd_lAhUFpY8KHRadDIoQjRx6BAgBEAQ&url=https%3A%2F%2Funsplash.com%2Fs%2Fphotos%2Fmiami&psig=AOvVaw3NVoF1YHk8X2wjAdfRcNPx&ust=1573454535612132'
        ),
        title: Text('Abhimanyu'),
        trailing: Icon(Icons.more_horiz),
      ),
      Image.network('hhttps://www.google.com/url?sa=i&source=imgres&cd=&cad=rja&uact=8&ved=2ahUKEwjOlc6Hhd_lAhUFpY8KHRadDIoQjRx6BAgBEAQ&url=https%3A%2F%2Funsplash.com%2Fs%2Fphotos%2Fmiami&psig=AOvVaw3NVoF1YHk8X2wjAdfRcNPx&ust=1573454535612132',
        height: 200,
        width: double.infinity,
        fit: BoxFit.cover, 
      ),

    ],
  );
}